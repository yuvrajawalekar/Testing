package seleniumTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonSelenium {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YUVRAJ\\Desktop\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseurl = "https://www.amazon.in/";
		
		String expectedTitle="Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		
		driver.get(baseurl);
		
		String actualTitle="";
		
		actualTitle=driver.getTitle();
		
		if(actualTitle.equals(expectedTitle)) 
		{
			System.out.println("Testing started...");
			
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Iphone 11");
			
			driver.findElement(By.className("nav-input")).click();
			
			System.out.println("Successfully Entered..");
		}
		else
		{
			System.out.println("test failed..");
		}
		  // driver.close();
		}
	
		
		
	}

