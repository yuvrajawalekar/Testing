package com.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Scanner;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestNumberTest {
	 
	private TestNumber n1=null;

	@BeforeEach
	void setUp() throws Exception {
		n1=new TestNumber();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void testPositiveSetNumber() {
		 n1.setNumber(101);
		 assertEquals(100, n1.getNumber());
	}
	
	public void NegativeSetNumber() {
		 n1.setNumber(-98);
		 assertEquals(0, n1.getNumber());
	}

}
