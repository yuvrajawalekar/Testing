package seleniumFacebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestFacebook {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\YUVRAJ\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		String baseurl="http://www.facebook.com";
		String expectedTitle="Facebook � log in or sign up";
		
		driver.get(baseurl);
		String actualTitle="";
		
		actualTitle=driver.getTitle();
		
		if(actualTitle.equals(expectedTitle))
		{
			System.out.println("Test Passed..");
			driver.findElement(By.name("firstname")).sendKeys("John");
			driver.findElement(By.name("lastname")).sendKeys("Cena");
			driver.findElement(By.name("reg_email__")).sendKeys("johncannotseeme@wwe.com");
			driver.findElement(By.name("reg_email_confirmation__")).sendKeys("johncannotseeme@wwe.com");
			driver.findElement(By.name("reg_passwd__")).sendKeys("John@12345");
			System.out.println("upto password Entered..");
			driver.findElement(By.name("birthday_day")).sendKeys("15");
			driver.findElement(By.name("birthday_month")).sendKeys("January");
			driver.findElement(By.name("birthday_year")).sendKeys("1996");
			System.out.println("upto dob Entered..");
			driver.findElement(By.id("u_0_6")).click();
			driver.findElement(By.name("websubmit")).click();
			
			
			System.out.println("Successfully Entered..");
		}
		else
		{
			System.out.println("Test Failed...");
		}	
		
		driver.close();

	}

}
