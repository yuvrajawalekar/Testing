package com.core;

public class TestNumber {
	private int number;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		if(number < 0) {
			this.number = 0;
	}
		else if(number > 100) {
			this.number=100;
		}
		else
			this.number=number;
	}
	

}
