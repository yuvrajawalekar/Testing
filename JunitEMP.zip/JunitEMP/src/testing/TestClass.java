package testing;

public class TestClass {

	
	public int square(int x)
	{
		return x*x;
	}
	
	public int countA(String str)
	{
		int count=0;
		for(int i = 0; i<str.length();i++)
		{
			if(str.charAt(i)=='a' || str.charAt(i)=='A')
			{
				count++;
			}
		}
		return count;
	}
	
	public boolean checkEmpID(String empid)
	{
		String id=empid;
		boolean status = false;
		char c1 = id.charAt(0);
		char c2 = id.charAt(1);
		if(c1 == 'I' && c2 == 'D')
		{
			status = true;
		}
		return status;
	}
	
	public boolean checkED(String ename, String dept)
	{
		boolean status = true;
		if(ename == null || dept == null)
		{
			status= false;
		}
		
		return status;
	}

	public boolean checkSal(double sal) 
	{
		boolean status = false;
		if(sal > 0)
		{
			status = true;
		}

		return status;
	}
}
