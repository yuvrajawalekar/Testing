package testing;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestEmployee {
	

	@Test
	public void test() {
		
		TestClass jtest = new TestClass();
		
		int output= jtest.square(7);
		
		assertEquals(49,output);
	}
	
	@Test
	public void test1() {
		
		TestClass jtest = new TestClass();
		
		int output= jtest.countA("alphabet");
		
		assertEquals(2,output);
	}
	
	@Test
	public void test2() {
		
		TestClass jtest = new TestClass();
		
		boolean output= jtest.checkEmpID("IDalphabet");
		
		assertEquals(true,output);
	}
	
	@Test
	public void test3() {
		
		TestClass jtest = new TestClass();
		
		boolean output= jtest.checkSal(4526.244);
		
		assertEquals(true,output);
	}

}
